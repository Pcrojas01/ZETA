// public/js/dashboard_admin.js

document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Usar la función autenticada para hacer la petición
    const res = await window.authUtils.authenticatedFetch('/api/reports/admin_dashboard');
    const data = await res.json();

    document.getElementById('total-users').textContent = data.totalUsers || 0;
    document.getElementById('total-teachers').textContent = data.totalTeachers || 0;
    document.getElementById('total-students').textContent = data.totalStudents || 0;
    document.getElementById('total-subjects').textContent = data.totalSubjects || 0;
    document.getElementById('total-comments').textContent = data.totalComments || 0;
  } catch (err) {
    window.authUtils.handleAuthError(err);
  }
});

// Función para cerrar sesión (ya está en main.js, pero la mantenemos por compatibilidad)
function cerrarSesion() {
  window.authUtils.logout();
}

// 👇 Esto es clave para que el onclick del HTML funcione
window.cerrarSesion = cerrarSesion;
